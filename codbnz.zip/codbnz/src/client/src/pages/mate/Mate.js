
const Mate = () => {
  return (
    <>
      <div className="inner_m">
        <h2 className="link_back">빈즈메이트</h2>
      </div>
    </>
  )
}

export default Mate