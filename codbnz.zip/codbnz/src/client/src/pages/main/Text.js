import React from 'react'

const MainText = () => {
  return (
    <>
      <div className="text">
        <h3>안녕, 코딩하는 콩들아!</h3>
        <p>같이 공부할 친구들이 필요한가요?<br />
          스터디. 프로젝트 어디서 모집하는지 모르겠나요?<br />
          코딩하는 콩들, 다 여기여기 모여라!<br />
        </p>
        <h2>codbnz</h2>
      </div>
    </>
  )
}

export default MainText