package we.cod.bnz.today.common;

/**
 * 권한 타입
 */
public enum Role {
    USER, ADMIN
}
