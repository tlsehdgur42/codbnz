package we.cod.bnz.account.dto;

import lombok.Data;

@Data
public class TokenRequest {

  private String token;

}
