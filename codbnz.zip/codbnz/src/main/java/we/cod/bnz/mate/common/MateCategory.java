package we.cod.bnz.mate.common;


public enum MateCategory {
    STUDY,
    PROJECT
    //    ALL("ALL");
//    private final String displayName;
//
//    MateCategory(String displayName) {
//        this.displayName = displayName;
//    }
//
//    public String getDisplayName() {
//        return displayName;
//    }
//
//    @Override
//    public String toString() {
//        return name();  // Enum 상수의 이름 반환
//    }
}
