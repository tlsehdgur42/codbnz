package we.cod.bnz.account.dto;

import lombok.Data;

@Data
public class ChangeTXT {

  private String username, email, nickname, profileMSG;

}
