package we.cod.bnz.account.dto;

import lombok.Data;

@Data
public class ChangeIMG {

  private String shape, color, eye, face;

}
