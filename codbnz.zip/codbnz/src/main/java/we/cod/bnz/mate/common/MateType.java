package we.cod.bnz.mate.common;

public enum MateType {
    ONLINE,
    OFFLINE
}