package we.cod.bnz.account.dto;

import lombok.Data;

@Data
public class LoginRequest {

  private String username, password;

}
